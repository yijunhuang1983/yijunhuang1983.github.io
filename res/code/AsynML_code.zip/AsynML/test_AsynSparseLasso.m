%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Sparse Lasso problem:

% min_w \|X * w - y\|^2  / (2*nSample) + + l_1 * \|w\|_1
% s.t.  lbound <= w <= ubound
%       X -- SPARSE data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]
%       l_1 -- prior parameter for L1-norm


clear;clc; close all

fprintf('\ntest Asyn-Lasso\n');

randn('state',1)
rand('state',1)


fprintf('\ngenerating synthetic data ... \n');
%% generate data-set

% the number of samples
nSample = 2000;
% the number of features
nFeature = 4000;

% generate data-set: 
% X -- dense data matrix [nSample,nFeature]
% y -- target value vector [nSample,1]

%sparsity of data matrix X
sp = 0.05; 

noise_level = 0.1;

X = sprandn(nSample,nFeature, sp);
y = X*randn(nFeature,1) + randn(nSample,1)*noise_level;

%% settings

% the number of threads
nThread = 4;

% l1 -- The prior parameter of l1-norm regularization (non-negative double).
l1 = 0.01;

% w0 -- the initial value of varialbes (empty [] or double or vector [nFeature,1].
w0 = []; % 1; %randn(nFeature,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 60;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = -inf;

% lower and upper bound of variable vector (empty [] or double or vector [nFeature,1]).
% constraint: lbound <= ubound
lbound = -1; %[];  %-1; %-rand(1)*ones(nFeature,1);
ubound = 1; %[]; % 1;  %rand(1)*ones(nFeature,1);



%% run AsynSparseLasso -- Asyn-SparseLasso
current = pwd;
cd('./matlab/AsynSparseLasso')

prob_SparseLasso = problem_SparseLasso(X, y, l1);
tic
[w_SparseLasso, obj_SparseLasso] = AsynSparseLasso(prob_SparseLasso, nThread, w0, lbound, ubound, maxEpoch, minObj);
toc
cd(current)

figure
semilogy(obj_SparseLasso)
title('Asyn-SparseElasitcNet')
ylabel('log\_Obj')
xlabel('#Epoch')

