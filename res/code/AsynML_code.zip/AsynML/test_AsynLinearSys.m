%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% LinearSyetem problem: 

% A * x = b  (A is sparse)
% data:     A--[M, N]
%           b--[M,1]
% variable: x--[N,1]


clear;clc; close all

fprintf('\ntest Asyn-LinearSys\n');


fprintf('\ngenerating synthetic data ... \n');
%% generate data

rand('state', 1); randn('state', 1);

M = 8000;
N = 10000;

% sparsity of matrix A
sp = 0.001; 

A = sprandn(M,N, sp);
b = A*randn(N,1);

% initial value of variable x: empty [] or double or vecotr [N,1]
x0 = []; % 1; % randn(N,1);

%% settings

% the number of threads
nThread =4;

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 500;

% minResidual -- Stopping criteria: the limit of redisual value (double): residual = \|Ax-b\|^2.
minResidual = 0;

% step size (positive double) used in the algorithm for update the variable x 
stepsize = 1;

%% run AsynLinearSys -- Asyn-LinearSys
current = pwd;
cd('./matlab/AsynLinearSys')

[x_LinearSys, residual_LinearSys] = AsynLinearSys(nThread, x0, A, b, stepsize, maxEpoch, minResidual);

cd(current)

figure
semilogy(residual_LinearSys)
title('Asyn-LinearSys')
ylabel('log\_redidual')
xlabel('#Epoch')

% residual = norm(A*x_LinearSys-b)^2;


