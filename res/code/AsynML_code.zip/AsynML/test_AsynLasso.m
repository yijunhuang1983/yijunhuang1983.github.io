%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Lasso problem:

% min_w \|X * w - y\|^2  / (2*nSample) + l_1 * \|w\|_1
% s.t.  lbound <= w <= ubound
%       X -- dense data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]
%       l_1 -- prior parameter for L1-norm


clear;clc; close all

fprintf('\ntest Asyn-Lasso\n');

randn('state',1)
rand('state',1)

fprintf('\ngenerating synthetic data ... \n');

%% generate data-set

% the number of samples
nSample = 1000;
% the number of features
nFeature = 4000;

% generate data-set: 
% X -- dense data matrix [nSample,nFeature]
% y -- target value vector [nSample,1]

noise_level = 0.1;

X = randn(nSample,nFeature); 
y = X*randn(nFeature,1) + randn(nSample,1)*noise_level;

%% settings

% the number of threads
nThread = 4;

% l1 -- The prior parameter of l1-norm regularization (non-negative double).
l1 = 0.2;

% w0 -- the initial value of varialbes (empty [] or double or vector [nFeature,1].
w0 = []; % 1; %randn(nFeature,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 100;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = 0;

% lower and upper bound of variable vector (empty [] or double or vector [nFeature,1]).
% constraint: lbound <= ubound
lbound = [];  %-1; %-rand(1)*ones(nFeature,1);
ubound = []; % 1;  %rand(1)*ones(nFeature,1);

%% run AsynLasso -- Asyn-Lasso


current = pwd;
cd('./matlab/AsynLasso')

prob_lasso = problem_Lasso(X, y, l1);
tic
[w_lasso, obj_lasso] = AsynLasso(prob_lasso, nThread, w0, lbound, ubound, maxEpoch, minObj);
toc

cd(current)

figure
semilogy(obj_lasso)
title('Asyn-Lasso')
ylabel('log\_Obj')
xlabel('#Epoch')