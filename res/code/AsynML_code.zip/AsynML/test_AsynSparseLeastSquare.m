%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Sparse Least Square problem:
% min_w \|X * w - y\|^2 
% s.t.  lbound <= x <= ubound
%       X -- sparse data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]

clear;clc; close all

fprintf('\ntest Asyn-SparseLeastSquare\n');
randn('state',1)
rand('state',1)

%% generate data-set

fprintf('\ngenerating synthetic data ... \n');

% the size of data matrix X 
% X is sparse
nSample = 20000;
nFeature = 40000;

%sparsity of X
sp = 0.005; 

% X -- sprse matrix 
% y -- target vector 
noise_level = 0.1;
X = sprandn(nSample,nFeature, sp);
y = X*randn(nFeature,1) + randn(nSample,1)*noise_level;

%% settings

% the number of threads
nThread = 4;

% x0 -- the initial value of the variable vector (empty [] or double or vector [N,1].
x0 = []; % 1; %randn(N,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 50;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = -inf;

% lower and upper bound of the variable vector (empty [] or double or vector [N,1]).
% constraint: lbound <= ubound
lbound = 0; % [];  %-1; %-rand(1)*ones(N,1);
ubound = 1; % []; % 1;  %rand(1)*ones(N,1);

%% run AsynSparseLeastSquare() -- Asyn-SparseLeastSquare
current = pwd;
cd('./matlab/AsynSparseLeastSquare')

tic
[x_SparseLeastSquare, obj_SparseLeastSquare] = AsynSparseLeastSquare(X, y, nThread, x0, lbound, ubound, maxEpoch, minObj);
toc

cd(current)

figure
semilogy(obj_SparseLeastSquare)
title('Asyn-SparseLeastSquare')
ylabel('log\_Obj')
xlabel('#Epoch')
