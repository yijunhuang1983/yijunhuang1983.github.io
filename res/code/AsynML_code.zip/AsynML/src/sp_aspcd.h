/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#ifndef _SP_ASPCD_H_
#define _SP_ASPCD_H_

#include "header.h"

typedef struct
{
	UINT id;
	UINT nThread;

    
    size_t * irA;
    size_t * jcA;
    double *srA;
    
    size_t * irAt;
    size_t * jcAt;
    double *srAt;
    
    
	FLOAT* w;
	FLOAT* b;
    
    FLOAT l1;
    FLOAT l2;

	FLOAT *lbound;
	FLOAT *ubound;

	FLOAT *stepsize;

	UINT p;
    UINT M;

	FLOAT obj;

	UINT *iBuffer;

} THRARGU_TRAIN;


extern UINT sp_aspcd (UINT nThread, UINT M, UINT p, double *srA, size_t *irA, size_t *jcA, double *srAt, size_t *irAt, size_t *jcAt, FLOAT* b, FLOAT l2, FLOAT l1, FLOAT *lbound, FLOAT *ubound, UINT maxEpoch, FLOAT minObj, FLOAT* w, FLOAT *objList);


/* object function: (1/2) * \|A * w - b\|^2 + l1*||w||_1   (A is sparse.)*/

#endif
