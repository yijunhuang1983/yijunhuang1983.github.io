/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "./../src/header.h"
#include "./../src/utl.h"
#include "mex.h"


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	mxArray *pm;
	double *ptr, l2, l1, minObj, *b, *w0, *w, *objList, *lbound, *ubound;
	unsigned long nThread, maxEpoch, p, M, nEpoch, i;
    
    size_t *irAt, *jcAt, *irA, *jcA;
    double *srAt, *srA;
    
    
    if(nrhs != 11)
		mexErrMsgTxt( "MATLAB:aspcd: 11 inputs required.");
    
	ptr = mxGetPr(prhs[0]);
	nThread = (unsigned long)(*ptr);
    
    
    srA  = mxGetPr(prhs[1]);
    irA = mxGetIr(prhs[1]);
    jcA = mxGetJc(prhs[1]);
    
    srAt  = mxGetPr(prhs[2]);
    irAt = mxGetIr(prhs[2]);
    jcAt = mxGetJc(prhs[2]);
    
    b = mxGetPr(prhs[3]);
    
    M = mxGetM(prhs[1]);
    p = mxGetN(prhs[1]);


    ptr = mxGetPr(prhs[4]);
    l2 = *ptr;
    ptr = mxGetPr(prhs[5]);
    l1 = *ptr;

    
    plhs[0] = mxCreateDoubleMatrix(p, 1, mxREAL);
    w = mxGetPr(plhs[0]);
    if ((mxGetM(prhs[6])==0) && (mxGetN(prhs[6])==0))
    {
        for (i=0; i<p; i++)
            w[i] = 0;
    }
    else
    {
        w0 = mxGetPr(prhs[6]);
        if ((mxGetM(prhs[6])==1) && (mxGetN(prhs[6])==1))
        {
            for (i=0; i<p; i++)
                w[i] = *w0;
        }
        else if (((mxGetM(prhs[6])==1) && (mxGetN(prhs[6])==p)) || ((mxGetM(prhs[6])==p) && (mxGetN(prhs[6])==1)))
            memcpy(w, w0, p*sizeof(double));
        else
            mexErrMsgTxt( "MATLAB:error in the initial value.");
    }
    
    
    
    if ((mxGetN(prhs[7])==0) || (mxGetM(prhs[7])==0))
    {
        lbound = 0;
    }
    else
    {
        lbound = mxGetPr(prhs[7]);
    }
    
    if ((mxGetN(prhs[8])==0) || (mxGetM(prhs[8])==0))
    {
        ubound = 0;
    }
    else
    {
        ubound = mxGetPr(prhs[8]);
    }
    
    ptr = mxGetPr(prhs[9]);
    maxEpoch = (unsigned long)(*ptr);
    ptr = mxGetPr(prhs[10]);
    minObj = *ptr;

	pm = mxCreateDoubleMatrix(maxEpoch, 1, mxREAL);
	objList = mxGetPr(pm);

    nEpoch = sp_aspcd (nThread, M, p, srA, irA, jcA, srAt, irAt, jcAt, b, l2, l1, lbound, ubound, maxEpoch, minObj, w, objList);
  
    PRINTF("\nnEpoch=%i\n", nEpoch);
    
    if (nEpoch==FALSE) {
        mexErrMsgTxt( "MATLAB:error in computing.");
    }
 
	plhs[1] = mxCreateDoubleMatrix(nEpoch, 1, mxREAL);
	ptr = mxGetPr(plhs[1]);
	memcpy(ptr, objList, nEpoch*sizeof(double));
	mxDestroyArray(pm);
    


	return;
}

