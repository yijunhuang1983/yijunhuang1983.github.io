/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "ark.h"
#include "utl.h"


void* ark_ThreadFunc(void * argc)
{
	UINT i,j,k,s,t;
	THRARGU_TRAIN * thrArgu;
	UINT id, M, N, *iBuffer, start_M, end_M, range_M;


	FLOAT *b, *x, gradi, stepsize, *A_row_2;
	
	double A_ij, At_ij, A_jk, Ax_j, Aix;
	double ai_2;
	double *srAt;
	size_t  *irAt, *jcAt;

	thrArgu = (THRARGU_TRAIN*) argc;
    
    id = thrArgu->id;
    stepsize = thrArgu->stepsize;
    M = thrArgu->M;
    N = thrArgu->N;
    b = thrArgu->b;
    x = thrArgu->x;

	srAt = thrArgu->srAt;
	jcAt = thrArgu->jcAt;
	irAt = thrArgu->irAt;

    split (id, M, thrArgu->nThread, &start_M, &end_M);
	range_M = end_M-start_M+1;
	iBuffer = thrArgu->iBuffer + start_M;
	A_row_2 = thrArgu->A_row_2;

	for (i = start_M; i <= end_M; i++)
	{
		ai_2 = 0;		

		for (s = jcAt[i]; s < jcAt[i+1]; s++)
		{
			A_ij = srAt[s];
			ai_2 += (A_ij * A_ij);
		}
		A_row_2[i] = ai_2;
	}

	while (1)
	{
/* update */

		Shuffle (iBuffer, start_M, range_M);

		barrier_wait(&b_wait);
        
		if(g_finish)
			return NULL;

		for (k = 0; k < range_M; k++)
		{
			i = iBuffer[k];

			Aix = 0;	

			for (s = jcAt[i]; s < jcAt[i+1]; s++)
			{
				j = irAt[s];
				A_ij = srAt[s];

				Aix += (A_ij * x[j]); 
			}

			gradi = stepsize * (Aix - b[i]) / (A_row_2[i]+_EPS_);

			for (s = jcAt[i]; s < jcAt[i+1]; s++)
			{
				j = irAt[s];
				A_ij = srAt[s];

				x[j] = x[j] - (gradi * A_ij); 
			}
        }

		barrier_wait(&b_wait);
        
        thrArgu->residual = 0;
		for (i = start_M; i<=end_M; i++)
        {			
			Aix = 0;

			for (s = jcAt[i]; s < jcAt[i+1]; s++)
			{
				j = irAt[s];
				A_ij = srAt[s];

				Aix += (A_ij * x[j]); 
			}

			(thrArgu->residual) += (Aix-b[i]) * (Aix-b[i]);
		}

		barrier_wait(&b_wait);
	}
}


UINT ark(UINT nThread, UINT M, UINT N, double *srAt, size_t *irAt, size_t *jcAt, FLOAT *b, FLOAT *x, FLOAT stepsize, UINT maxEpoch, FLOAT minResidual, FLOAT *residual_list)
{
	UINT i, j, nEpoch, *iBuffer, memLen;	
	void *mem;
	INT err;
	pthread_t *tid;
	THRARGU_TRAIN *thrArgu;
	FLOAT * A_row_2;


	PRINTF("\nin ark() ... \n");
	g_finish = FALSE;
	nEpoch = 0;



	if (nThread > M)
	{
		PRINTF ("\nnThread(%i) should be no greater than M(%i)\n", nThread, M);
		return FALSE;
	}

    
	memLen = nThread*sizeof(pthread_t) + nThread*sizeof(THRARGU_TRAIN) + M*sizeof(UINT) + M*sizeof(FLOAT);
	mem = (void*) malloc(memLen);

	if (!mem)
	{
		PRINTF ("\nfailed to allocate space\n");
		return FALSE;
	}
	tid = (pthread_t*)mem;
	thrArgu = (THRARGU_TRAIN*)(tid + nThread);
	iBuffer = (UINT *)(thrArgu + nThread);
	A_row_2 = (FLOAT *)(iBuffer + M);

	barrier_init(&b_wait, NULL, nThread+1);

	for (i = 0; i < nThread; i++) 
	{
		thrArgu[i].id = i;
		thrArgu[i].nThread = nThread;

		thrArgu[i].M = M;
		thrArgu[i].N = N;

		thrArgu[i].srAt = srAt;
		thrArgu[i].irAt = irAt;
		thrArgu[i].jcAt = jcAt;

		thrArgu[i].b = b;
		thrArgu[i].x = x;

		thrArgu[i].stepsize = stepsize;
		thrArgu[i].iBuffer = iBuffer;
		thrArgu[i].A_row_2 = A_row_2;

		err = pthread_create(&tid[i], NULL, ark_ThreadFunc, (void *)(&thrArgu[i]));
        
		if (err != 0) 
		{
			PRINTF ("\nfailed to creat the threads\n"); 
			free(mem);
			return 0;
		}
	}


	PRINTF ("\n%i threads are solving the problem ...\n", nThread);

	for(nEpoch = 0; nEpoch < maxEpoch; nEpoch++)
	{

		barrier_wait(&b_wait);
/* update */
		/* waiting for updating w */
		PRINTF ("begin epoch(%i/%i)......", nEpoch+1, maxEpoch);

/* compute residual */

		barrier_wait(&b_wait);
		PRINTF ("compute residual......");

        barrier_wait(&b_wait);
        
		residual_list[nEpoch] = 0;
		for (i = 0; i < nThread; i++) 
		{
			residual_list[nEpoch] += thrArgu[i].residual;
		}

		PRINTF ("done: residual (\|\|Ax-b\|\|^2) = %f\n", residual_list[nEpoch]);

/* check criteria */
		
		if (residual_list[nEpoch] <= minResidual)
		{
			PRINTF ("\nachieved the minimum residual value\n");
			nEpoch ++;
			g_finish = TRUE;
			break;
		}
        
	}
	g_finish = TRUE;

	barrier_wait(&b_wait);

	for (i = 0; i < nThread; i++) 
	{
		err = pthread_join(tid[i], NULL);
		if (err != 0)
		{
			PRINTF ("\nfailed to joint the threads\n"); 
			free(mem);

			return FALSE;
		}
	}
	if (nEpoch<maxEpoch)
	{
		for (i=nEpoch; i<maxEpoch; i++)
		{
			residual_list[i] = _INF_;
		}
	}

	free(mem);
	PRINTF ("\nfinish\n"); 
	return nEpoch;


}

