/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "utl.h"
UINT g_seed;
BOOL g_finish;


barrier_t b_wait;

UINT RandUnsignedInt(UINT range) 
{
	return (UINT) ( ((FLOAT) range) * (rand_r(&g_seed) / (RAND_MAX + 1.0)));
}


void Shuffle (UINT * p, UINT low, UINT len)
{
	UINT tmp, pos;
	INT i;

	for (i = 0; i < len; i++)
	{
		p[i] = i + low;
	}

	for (i = len-1; i >= 0; i--)
	{
	    pos = RandUnsignedInt(i+1);
	    tmp = p[pos];
	    p[pos] = p[i];
	    p[i] = tmp;
	}
	return;
}


void split (UINT index, UINT Len, UINT nPortion, UINT *pStart, UINT *pEnd)
{
	UINT range, mod, start, end;


	range =  Len / nPortion;
	mod =  Len % nPortion;

	if (mod != 0)
	{
		if (index < mod)
		{
			start = (range+1) * index ;
			end = start + range;
			range ++;
		}
		else
		{
			start = (range+1) * mod + range * (index-mod) ;
			end = start + range - 1;
		}
	}
	else
	{
		start = range * index ;
		end = start + range - 1;
	}

	*pStart = start;
	*pEnd = end;
}




int barrier_init(barrier_t *b, void* attr, int count) 
{
#ifdef _APPLE_

	pthread_mutex_init(&b->mux, NULL);
	pthread_cond_init(&b->cond, NULL);
	b->total = count;
	b->current = count;
	return 0;

#else

	return pthread_barrier_init(b, (pthread_barrierattr_t*)attr, count);

#endif
}

int barrier_wait(barrier_t *b) 
{
#ifdef _APPLE_
	pthread_mutex_lock(&b->mux);
	b->current--;
	if (b->current == 0) 
	{
		b->current = b->total;
		pthread_cond_broadcast(&b->cond);
		pthread_mutex_unlock(&b->mux);
		return 0;
	} 

	pthread_cond_wait(&b->cond, &b->mux);
	pthread_mutex_unlock(&b->mux);
	return 0;

#else
	return pthread_barrier_wait(b);
#endif
}


int barrier_destroy(barrier_t *b) 
{
#ifdef _APPLE_
	return -1;
#else
	return pthread_barrier_destroy(b);
#endif

}







