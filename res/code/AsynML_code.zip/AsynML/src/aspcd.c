/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "aspcd.h"
#include "utl.h"


void* aspcd_ThreadFunc(void * argc)
{
	UINT i,j,k;
	THRARGU_TRAIN * thrArgu;
	UINT id, N, p, *iBuffer;
	FLOAT gradi, wi, *stepsize, *Q, *w, *B, tmpF1, *Qi;
	UINT start_p, end_p, range_p;
#ifdef _L1_
    FLOAT l1;
#endif
    
	FLOAT *lbound, *ubound;

	thrArgu = (THRARGU_TRAIN*) argc;
    
    stepsize = thrArgu->stepsize;
    p = thrArgu->p;
    id = thrArgu->id;
    B = thrArgu->B;
    
#ifdef _L1_
    l1 = thrArgu->l1;
#endif

	ubound = thrArgu->ubound;
	lbound = thrArgu->lbound;

    split (id, p, thrArgu->nThread, &start_p, &end_p);
    
	range_p = end_p-start_p+1;
	iBuffer = thrArgu->iBuffer + start_p;
    
/* prepare stepsize */
    Q = thrArgu->Q;
	for (i = start_p; i <= end_p; i++)
	{
		stepsize[i] = 1/(Q[i*p+i]+_EPS_);
    }

	while (1)
	{
/* update */

		Shuffle (iBuffer, start_p, range_p);

		barrier_wait(&b_wait);
        
		if(g_finish)
			return NULL;

        w = thrArgu->w;
		for (k = 0; k < range_p; k++)
		{
			i = iBuffer[k];
			gradi = 0;
			Qi = thrArgu->Q+i*p;
            
			for (j = 0; j < p; j++)
			{
				gradi += (*Qi)*(*w);
				Qi++;
				w++;
			}
            gradi -= B[i];
            
            w = thrArgu->w;
			wi = w[i]- stepsize[i]*gradi;
            
#ifdef _L1_
            if(l1>0)
            {
                tmpF1 = stepsize[i] * l1;
                if (wi > tmpF1)  wi -= tmpF1;
                else if(wi < -tmpF1)  wi += tmpF1;
                else wi = 0;
            }
#endif

            if(ubound)
            {
                if (wi > ubound[i]) wi = ubound[i];
            }
            if(lbound)
            {
                if (wi < lbound[i]) wi = lbound[i];
            }

			w[i] = wi;
        }

/* obj */
		barrier_wait(&b_wait);
        
        thrArgu->obj = 0;

		Qi = thrArgu->Q + start_p*p;
		for (i = start_p; i<=end_p; i++)
        {
			tmpF1 = 0;
			for (j = 0; j <p; j++)
            {
                tmpF1 += (*Qi)*(*w);
				Qi++;
				w++;
			}
            
            w = thrArgu->w;
			(thrArgu->obj) += (w[i]*tmpF1/2 - B[i]*w[i]);
		}
#ifdef _L1_
        if(l1>0)
        {
            w = thrArgu->w + start_p;
            tmpF1 = 0;
            for (i = start_p; i<=end_p; i++)
            {
                tmpF1 += fabs(*w);
                w++;
            }
            (thrArgu->obj) += l1*tmpF1;
            w = thrArgu->w;
        }
#endif

		barrier_wait(&b_wait);
	}
}

UINT aspcd (UINT nThread, UINT p, FLOAT* Q, FLOAT* B, FLOAT C, FLOAT l1, FLOAT *lbound, FLOAT *ubound, UINT maxEpoch, FLOAT minObj, FLOAT* w, FLOAT *objList)
{
	UINT i, j, nEpoch, *iBuffer, memLen;	
	void *mem;
	INT err;
	pthread_t *tid;
	THRARGU_TRAIN *thrArgu;
	FLOAT *stepsize;

	PRINTF("\nin aspcd() ... \n");
	g_finish = FALSE;

	nEpoch = 0;

	if (nThread > p)
	{
		PRINTF ("\nnThread(%i) should be no greater than p(%i)\n", nThread, p);
		return FALSE;
	}
    
	memLen = nThread*sizeof(pthread_t) + nThread*sizeof(THRARGU_TRAIN) + p*sizeof(FLOAT) + p*sizeof(UINT);
	mem = (void*) malloc(memLen);

	if (!mem)
	{
		PRINTF ("\nfailed to allocate space\n");
		return FALSE;
	}
	tid = (pthread_t*)mem;
	thrArgu = (THRARGU_TRAIN*)(tid + nThread);
	stepsize = (FLOAT*)(thrArgu + nThread);
	iBuffer = (UINT *)(stepsize+p);

	barrier_init(&b_wait, NULL, nThread+1);

	for (i = 0; i < nThread; i++) 
	{
		thrArgu[i].id = i;
		thrArgu[i].nThread = nThread;

		thrArgu[i].w = w;
        thrArgu[i].Q = Q;
        thrArgu[i].B = B;
        
#ifdef _L1_
		thrArgu[i].l1 = l1;
#endif

		thrArgu[i].lbound = lbound;
		thrArgu[i].ubound = ubound;

		thrArgu[i].p = p;
		thrArgu[i].stepsize = stepsize;
		thrArgu[i].iBuffer = iBuffer;

		err = pthread_create(&tid[i], NULL, aspcd_ThreadFunc, (void *)(&thrArgu[i]));
        
		if (err != 0) 
		{
			PRINTF ("\nfailed to creat the threads\n"); 
			free(mem);
			return 0;
		}
	}

	PRINTF ("\n%i threads are solving the problem ...\n", nThread);

	for(nEpoch = 0; nEpoch < maxEpoch; nEpoch++)
	{

		barrier_wait(&b_wait);
/* update */
		/* waiting for updating w */
		PRINTF ("begin epoch(%i/%i)......", nEpoch+1, maxEpoch);

/* compute obj */

		barrier_wait(&b_wait);
		PRINTF ("compute object......");

        barrier_wait(&b_wait);
        
		objList[nEpoch] = 0;
		for (i = 0; i < nThread; i++) 
		{
			objList[nEpoch] += thrArgu[i].obj;
		}
        objList[nEpoch] += C;

		PRINTF ("done: obj = %f\n", objList[nEpoch]);

/* check criteria */
		
		if (objList[nEpoch] <= minObj)
		{
			PRINTF ("\nachieved the minimum object value\n");
			nEpoch ++;
			g_finish = TRUE;
			break;
		}
        
	}
	g_finish = TRUE;

	barrier_wait(&b_wait);

	for (i = 0; i < nThread; i++) 
	{
		err = pthread_join(tid[i], NULL);
		if (err != 0)
		{
			PRINTF ("\nfailed to joint the threads\n"); 
			free(mem);

			return FALSE;
		}
	}

	if (nEpoch<maxEpoch)
	{
		for (i=nEpoch; i<maxEpoch; i++)
		{
			objList[i] = _INF_;
		}
	}

	free(mem);
	PRINTF ("\nfinish\n"); 
	return nEpoch;

}


