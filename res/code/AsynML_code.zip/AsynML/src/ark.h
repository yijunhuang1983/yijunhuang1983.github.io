/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#ifndef _ARK_H_
#define _ARK_H_

#include "header.h"


typedef struct
{
	UINT id;
	UINT nThread;

	UINT M;        
	UINT N;         

	size_t * irAt;
	size_t * jcAt;
	double *srAt;

	FLOAT * b;
	FLOAT * x;
	FLOAT * A_row_2;

	FLOAT stepsize;
	
	FLOAT residual;

	UINT *iBuffer;

} THRARGU_TRAIN;


extern UINT ark(UINT nThread, UINT M, UINT N, double *srAt, size_t *irAt, size_t *jcAt, FLOAT *b, FLOAT *x, FLOAT stepsize, UINT maxEpoch, FLOAT minResidual, FLOAT *residual_list);


#endif
