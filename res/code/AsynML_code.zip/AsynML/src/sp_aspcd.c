/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "sp_aspcd.h"
#include "utl.h"


void* sp_aspcd_ThreadFunc(void * argc)
{
    UINT i,j,k,s,t, cnt;
	THRARGU_TRAIN * thrArgu;
	UINT id, M, p, *iBuffer;
    FLOAT gradi, wi, *stepsize, *w, *b, tmpF1, tmpF2;
    UINT start_p, end_p, range_p;
    UINT start_M, end_M;
    
    double A_col_2, A_ij, At_ij, A_jk, Aw_j, Atb_i, Aw_i;
    double *srAt, *srA;
    size_t  *irAt, *jcAt, *irA, *jcA;
    
	FLOAT l2;
#ifdef _L1_
    FLOAT l1;
#endif
    
	FLOAT *lbound, *ubound;

	thrArgu = (THRARGU_TRAIN*) argc;
    
    stepsize = thrArgu->stepsize;
    p = thrArgu->p;
    M = thrArgu->M;
    id = thrArgu->id;
    b = thrArgu->b;
    
	w = thrArgu->w;
    
    srA = thrArgu->srA;
    jcA = thrArgu->jcA;
    irA = thrArgu->irA;
    
    srAt = thrArgu->srAt;
    jcAt = thrArgu->jcAt;
    irAt = thrArgu->irAt;
    
#ifdef _L1_
    l1 = thrArgu->l1;
#endif

	ubound = thrArgu->ubound;
	lbound = thrArgu->lbound;
    
    split (id, p, thrArgu->nThread, &start_p, &end_p);
    split (id, M, thrArgu->nThread, &start_M, &end_M);
    
	range_p = end_p-start_p+1;
	iBuffer = thrArgu->iBuffer + start_p;
    
/* prepare stepsize */

	for (i = start_p; i <= end_p; i++)
    {
        A_col_2 = 0;
        for (s = jcA[i]; s < jcA[i+1]; s++)
        {
            j = irA[s];
            At_ij = srA[s];
            A_col_2 += (At_ij * At_ij);
        }
        stepsize[i] = 1/(A_col_2+_EPS_);
    }

	while (1)
	{
/* update */

		Shuffle (iBuffer, start_p, range_p);

		barrier_wait(&b_wait);
        
		if(g_finish)
			return NULL;

        
		for (cnt = 0; cnt < range_p; cnt++)
		{
			i = iBuffer[cnt];
            
            gradi = 0;
            Atb_i = 0;

            for (s = jcA[i]; s < jcA[i+1]; s++)
            {
                j = irA[s];
                At_ij = srA[s];
                Atb_i += (At_ij * b[j]);

                Aw_j = 0;                

                for (t = jcAt[j]; t < jcAt[j+1]; t++)
                {


                    k = irAt[t];
                    A_jk = srAt[t];
                    
                    Aw_j += (A_jk * w[k]);
                }

                gradi += (At_ij * Aw_j);

            }
            
            gradi = gradi -Atb_i + l2;
        
			wi = w[i]- stepsize[i]*gradi;
            
#ifdef _L1_
            if(l1>0)
            {
                tmpF1 = stepsize[i] * l1;
                if (wi > tmpF1)  wi -= tmpF1;
                else if(wi < -tmpF1)  wi += tmpF1;
                else wi = 0;
            }
#endif

            if(ubound)
            {
                if (wi > ubound[i]) wi = ubound[i];
            }
            if(lbound)
            {
                if (wi < lbound[i]) wi = lbound[i];
            }


			w[i] = wi;

        }

/* obj */
		barrier_wait(&b_wait);
        
        thrArgu->obj = 0;

		for (i = start_M; i<=end_M; i++)
        {
            Aw_i = 0;
            for (s = jcAt[i]; s < jcAt[i+1]; s++)
            {
                j = irAt[s];
                A_ij = srAt[s];
                Aw_i += A_ij*w[j];
            }
            thrArgu->obj += ((Aw_i - b[i])*(Aw_i - b[i]));
        }
        thrArgu->obj /= 2;
        
        tmpF2 = 0;
        tmpF1 = 0;
        for (i = start_p; i<=end_p; i++)
        {
			wi = w[i];
			tmpF2 += (wi*wi);
#ifdef _L1_
            tmpF1 += fabs(wi);
#endif
        }

#ifdef _L1_
		(thrArgu->obj) += (tmpF2*l2/2 + l1*tmpF1);
#else
		(thrArgu->obj) += (tmpF2*l2/2);
#endif

        

		barrier_wait(&b_wait);
	}
}

UINT sp_aspcd (UINT nThread, UINT M, UINT p, double *srA, size_t *irA, size_t *jcA, double *srAt, size_t *irAt, size_t *jcAt, FLOAT* b, FLOAT l2, FLOAT l1, FLOAT *lbound, FLOAT *ubound, UINT maxEpoch, FLOAT minObj, FLOAT* w, FLOAT *objList)
{
	UINT i, j, nEpoch, *iBuffer, memLen;	
	void *mem;
	INT err;
	pthread_t *tid;
	THRARGU_TRAIN *thrArgu;
	FLOAT *stepsize;

	PRINTF("\nin sp_aspcd() ... \n");
	g_finish = FALSE;

	nEpoch = 0;

	if (nThread > p)
	{
		PRINTF ("\nnThread(%i) should be no greater than p(%i)\n", nThread, p);
		return FALSE;
	}
    
	memLen = nThread*sizeof(pthread_t) + nThread*sizeof(THRARGU_TRAIN) + p*sizeof(FLOAT) + p*sizeof(UINT);
	mem = (void*) malloc(memLen);

	if (!mem)
	{
		PRINTF ("\nfailed to allocate space\n");
		return FALSE;
	}
	tid = (pthread_t*)mem;
	thrArgu = (THRARGU_TRAIN*)(tid + nThread);
	stepsize = (FLOAT*)(thrArgu + nThread);
	iBuffer = (UINT *)(stepsize+p);

	barrier_init(&b_wait, NULL, nThread+1);

	for (i = 0; i < nThread; i++) 
	{
		thrArgu[i].id = i;
		thrArgu[i].nThread = nThread;

		thrArgu[i].w = w;
        thrArgu[i].b = b;
        
        thrArgu[i].srA = srA;
        thrArgu[i].irA = irA;
        thrArgu[i].jcA = jcA;
        
        thrArgu[i].srAt = srAt;
        thrArgu[i].irAt = irAt;
        thrArgu[i].jcAt = jcAt;

		thrArgu[i].l2 = l2;
        
#ifdef _L1_
		thrArgu[i].l1 = l1;
#endif

		thrArgu[i].lbound = lbound;
		thrArgu[i].ubound = ubound;
        
        thrArgu[i].p = p;
        thrArgu[i].M = M;
		thrArgu[i].stepsize = stepsize;
		thrArgu[i].iBuffer = iBuffer;

		err = pthread_create(&tid[i], NULL, sp_aspcd_ThreadFunc, (void *)(&thrArgu[i]));
        
		if (err != 0) 
		{
			PRINTF ("\nfailed to creat the threads\n"); 
			free(mem);
			return 0;
		}
	}

	PRINTF ("\n%i threads are solving the problem ...\n", nThread);

	for(nEpoch = 0; nEpoch < maxEpoch; nEpoch++)
	{

		barrier_wait(&b_wait);
/* update */
		/* waiting for updating w */
		PRINTF ("begin epoch(%i/%i)......", nEpoch+1, maxEpoch);

/* compute obj */

		barrier_wait(&b_wait);
		PRINTF ("compute object......");

        barrier_wait(&b_wait);
        
		objList[nEpoch] = 0;
		for (i = 0; i < nThread; i++) 
		{
			objList[nEpoch] += thrArgu[i].obj;
		}

		PRINTF ("done: obj = %f\n", objList[nEpoch]);

/* check criteria */
		
		if (objList[nEpoch] <= minObj)
		{
			PRINTF ("\nachieved the minimum object value\n");
			nEpoch ++;
			g_finish = TRUE;
			break;
		}
        
	}
	g_finish = TRUE;

	barrier_wait(&b_wait);

	for (i = 0; i < nThread; i++) 
	{
		err = pthread_join(tid[i], NULL);
		if (err != 0)
		{
			PRINTF ("\nfailed to joint the threads\n"); 
			free(mem);

			return FALSE;
		}
	}

	if (nEpoch<maxEpoch)
	{
		for (i=nEpoch; i<maxEpoch; i++)
		{
			objList[i] = _INF_;
		}
	}

	free(mem);
	PRINTF ("\nfinish\n"); 
	return nEpoch;

}


