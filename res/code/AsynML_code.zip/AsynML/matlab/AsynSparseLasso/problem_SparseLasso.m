function prob = problem_SparseLasso(X, y, l1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- Sample-set (sparse matrix [nSample,nFeature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  l1 -- The prior parameter of l1-norm regularization (non-negative double).
%% output:
%  prob -- the input data for AsynSparseLasso()


inputErr = false;

[nSample, nFeature] = size(X);

if ~(isvector(y) && (length(y)==nSample))
	inputErr = true;
end


if l1<0
    inputErr = true;
else
    l1 = double(l1);
end

if inputErr
    fprintf('\nproblem_RR: error in inputs\n');
    return;
end

prob.A = X/sqrt(nSample);
prob.b = y/sqrt(nSample);
prob.l1 = l1;

end