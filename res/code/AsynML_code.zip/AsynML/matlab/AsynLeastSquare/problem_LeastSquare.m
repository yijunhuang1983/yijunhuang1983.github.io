function prob = problem_LeastSquare(X, y)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- matrix ([nSample,nFeature]).
%  y -- vector (vector [nSample,1]).
%% output:
%  prob -- the input data for AsynLeastSquare()


[nSample, nFeature] = size(X);

if ~(isvector(y) && (length(y)==nSample))
    fprintf('\nproblem_LeastSquare: error in inputs\n');
    return;
end


prob.Q = 2*X'*X;
prob.B = 2*X'*y;
prob.C = y'*y;

end