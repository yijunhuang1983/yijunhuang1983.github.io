function prob = problem_SparseElasticNet(X, y, l2, l1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- Sample-set (sparse matrix [nSample,nFeature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  l2 -- The prior parameter of l2-norm regularization (non-negative double).
%  l1 -- The prior parameter of l1-norm regularization (non-negative double).
%% output:
%  prob -- the input data for AsynSparseElasticNet()


inputErr = false;

[nSample, nFeature] = size(X);

if ~(isvector(y) && (length(y)==nSample))
	inputErr = true;
end

if l2<0
    inputErr = true;
else
    l2 = double(l2);
end

if l1<0
    inputErr = true;
else
    l1 = double(l1);
end

if inputErr
    fprintf('\nproblem_RR: error in inputs\n');
    return;
end

prob.A = X/sqrt(nSample);
prob.b = y/sqrt(nSample);
prob.l2 = l2;
prob.l1 = l1;

end