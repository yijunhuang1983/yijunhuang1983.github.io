function [x, residual_list] = AsynLinearSys(nThread, x0, A, b, stepsize, maxEpoch, minResidual)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% solve large scale linear system: A * x = b
%  A -- matrix: [M,N]
%  b -- vector [N,1]
%  x -- variable vector

%% inputs:
%  nThread -- The number of threads (positive integer).
%  x0 -- initial value of variable x (empty [] or double or vecotr [N,1]).
%  stepsize -- step size (positive double) used in the algorithm for update the variable x
%  minresidual -- Stopping criteria: the limit of redisual value (double): residual = \|Ax-b\|^2..
%  maxEpoch -- Stopping criteria: the limit the of epochs (positive integer).
%% outputs:
%  x -- The result of variable x.
%  residual_list -- The residual value at each epoch.


inputErr = false;

if ~issparse(A)
    inputErr = true;
    fprintf('\ninput data matrix A must be sparse\n');
else
    [M,N] = size(A);
end

if ~((isvector(b)) && (length(b)==M))
    inputErr = true;
end

    
 
if (nThread<1)
    inputErr = true;
else
    nThread = uint64(nThread);
end

if (maxEpoch<1)
    inputErr = true;
else
    maxEpoch = uint64(maxEpoch);
end

minResidual = double(minResidual);

if (stepsize<=0)
    inputErr = true;
else
    stepsize = double(stepsize);
end




if ~isempty(x0)
   if isvector(x0)
       if length(x0) ==1
           x0 = x0*ones(N,1);
       else if length(x0) ~= N
               inputErr = true;
           end
       end
   else
       inputErr = true;
   end
end


if inputErr
    fprintf('\nAsynLinearSys: error in inputs\n');
    return;
end


%% compile 'ark' 
current = pwd;
cd('../tools')
compile_ark(current)
cd(current)
%%


tic;
[x, residual_list] = m_ark(double(nThread), A', b, x0, stepsize, double(maxEpoch), minResidual);
toc;

return;