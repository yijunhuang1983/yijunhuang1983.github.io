function compile_ark(outpath)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% ark is implemented to solve:
% A * x = b
% A is a sparse matrix

if ismac
    % Code to run on Mac plaform
    eval(['mex ./../../src/m_ark.c ./../../src/ark.c ./../../src/utl.c -lpthread -largeArrayDims -D_MATLAB_ -D_APPLE_ -outdir ', outpath])
    
elseif isunix
    % Code to run on Linux plaform
    eval(['mex ./../../src/m_ark.c ./../../src/ark.c ./../../src/utl.c -lpthread -largeArrayDims -D_MATLAB_ -outdir ', outpath])

    
elseif ispc
    % Code to run on Windows platform
	disp('Windows Platform not supported')
    
else
    disp('Platform not supported')
    
end






