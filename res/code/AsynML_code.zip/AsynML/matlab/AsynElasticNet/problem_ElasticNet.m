function prob = problem_ElasticNet(X, y, l2, l1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- Sample-set (matrix [nSample,#Feature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  l2 -- The prior parameter of l2-norm regularization (non-negative double).
%  l1 -- The prior parameter of l1-norm regularization (non-negative double).
%% output:
%  prob -- the input data for AsynElasticNet()


inputErr = false;

[nSample, nFeature] = size(X);

if ~(isvector(y) && (length(y)==nSample))
	inputErr = true;
end

if l2<0
    inputErr = true;
else
    l2 = double(l2);
end

if l1<0
    inputErr = true;
else
    l1 = double(l1);
end

if inputErr
    fprintf('\nproblem_RR: error in inputs\n');
    return;
end

prob.Q = X'*X/nSample + l2*eye(nFeature);
prob.B = X'*y/nSample;
prob.C = y'*y/(2*nSample);
prob.l1 = l1;

end