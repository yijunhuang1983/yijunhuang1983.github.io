function [w, obj_list] = AsynSparseLeastSquare(X, y, nThread, w0, lbound, ubound, maxEpoch, minObj)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% objective function:
% min_w \|X * w - y\|^2 
% s.t.  lbound <= x <= ubound
%       X -- sparse data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]

%% inputs:
%  X -- Sample-set (sparse matrix [nSample,#Feature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  nThread -- The number of threads (positive integer).
%  w0 -- the initial value of varialbes (vector [nFeature,1] or empty [] or double).
%  lbound, ubount -- The lower and upper bound of variables (vector [nFeature,1] or empty [] or double).
%  minObj -- Stopping criteria: the limit of objective function value (double).
%  maxEpoch -- Stopping criteria: the limit the of epochs (positive integer).
%% outputs:
%  w -- The result of variable by trained.
%  obj_list -- The objective function value at each epoch.


%%
inputErr = false;

if ~issparse(X)
    inputErr = true;
    fprintf('\ninput data matrix X must be sparse\n');
else
    [nSample,nFeature] = size(X);
end


if ~((isvector(y)) && (length(y)==nSample))
    inputErr = true;
end

if (nThread<1)
    inputErr = true;
else
    nThread = uint64(nThread);
end

if (maxEpoch<1)
    inputErr = true;
else
    maxEpoch = uint64(maxEpoch);
end

minObj = double(minObj);

if ~isempty(w0)
   if isvector(w0)
       if length(w0) ==1
           w0 = w0*ones(nFeature,1);
       else if length(w0) ~= nFeature
               inputErr = true;
           end
       end
   else
       inputErr = true;
   end
end

if ~isempty(lbound)
   if isvector(lbound)
       if length(lbound) ==1
           lbound = lbound*ones(nFeature,1);
       else if length(lbound) ~= nFeature
               inputErr = true;
           end
       end
   else
       inputErr = true;
   end
end

if ~isempty(ubound)
   if isvector(ubound)
       if length(ubound) ==1
           ubound = ubound*ones(nFeature,1);
       else if length(ubound) ~= nFeature
               inputErr = true;
           end
       end
   else
       inputErr = true;
   end
end

if ~(isempty(lbound) || isempty(ubound))
    if sum(lbound>ubound)
        inputErr = true;
    end
end

if inputErr
    fprintf('\nAsynElasticNet: error in inputs\n');
    return;
end


%% compile 'sp_aspcd' 

L1 = false;
current = pwd;
cd('../tools')
compile_sp_aspcd(L1, current)
cd(current)

%%
% l2 = 0;
% l1 = 0;

[w, obj_list] = m_sp_aspcd(double(nThread), X, X', y, 0, 0, w0, lbound, ubound, double(maxEpoch), minObj); 


return
