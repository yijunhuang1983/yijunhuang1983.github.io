%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Least Square problem:
% min_w \|X * w - y\|^2 
% s.t.  lbound <= w <= ubound
%       X -- dense data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]

clear;clc; close all

fprintf('\ntest Asyn-LeastSquare\n');

randn('state',1)
rand('state',1)

%% generate data-set

fprintf('\ngenerating synthetic data ... \n');

% the size of matrix X
nSample = 2000;
nFeature = 4000;

noise_level = 0.1;

% X -- matrix [nSample,nFeature]
% y -- vector [nSample,1]
X = randn(nSample,nFeature); 
y = X*randn(nFeature,1) + randn(nSample,1)*noise_level;

%% settings

% the number of threads
nThread = 4;

% x0 -- the initial value of the variable vector (empty [] or double or vector [nFeature,1].
x0 = []; % 1; %randn(nFeature,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 40;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = -inf;

% lower and upper bound of the variable vector (empty [] or double or vector [nFeature,1]).
% constraint: lbound <= ubound
lbound = 0; % [];  %-1; %-rand(1)*ones(nFeature,1);
ubound = 1; % []; % 1;  %rand(1)*ones(nFeature,1);

%% run AsynLeastSquare() -- Asyn-LeastSquare
current = pwd;
cd('./matlab/AsynLeastSquare')

prob_LeastSquare = problem_LeastSquare(X, y);
tic
[x_LeastSquare, obj_LeastSquare] = AsynLeastSquare(prob_LeastSquare, nThread, x0, lbound, ubound, maxEpoch, minObj);
toc

cd(current)

figure
semilogy(obj_LeastSquare)
title('Asyn-LeastSquare')
ylabel('log\_Obj')
xlabel('#Epoch')