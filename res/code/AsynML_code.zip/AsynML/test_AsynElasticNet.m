%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% ElasticNet problem:

% min_w \|X * w - y\|^2  / (2*nSample) + (l_2 / 2) * \|w\|^2 + l_1 * \|w\|_1
% s.t.  lbound <= w <= ubound
%       X -- dense data matirx with size: [nSample,nFeature]
%       y -- target value vector with size: [nSample,1]
%       w -- variable vector with size: [nFeature, 1]
%       l_2, l_1 -- prior parameters for L2-norm and L1-norm


clear;clc; close all

fprintf('\ntest Asyn-ElasticNet\n');

randn('state',1)
rand('state',1)


fprintf('\ngenerating synthetic data ... \n');
%% generate data-set

% the number of samples
nSample = 100;
% the number of features
nFeature = 400;

% generate data-set: 
% X -- dense data matrix [nSample,nFeature]
% y -- target value vector [nSample,1]

noise_level = 0.1;

X = randn(nSample,nFeature); 
y = X*randn(nFeature,1) + randn(nSample,1)*noise_level;

%% settings

% the number of threads
nThread = 4;

% l1 -- The prior parameter of l1-norm regularization (non-negative double).
l1 = 0.2;

% l2 -- The prior parameter of l2-norm regularization (non-negative double).
l2 = 0.5; 

% w0 -- the initial value of varialbes (empty [] or double or vector [nFeature,1].
w0 = []; % 1; %randn(nFeature,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 60;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = 0;

% lower and upper bound of variable vector (empty [] or double or vector [nFeature,1]).
% constraint: lbound <= ubound
lbound = [];  %-1; %-rand(1)*ones(nFeature,1);
ubound = []; % 1;  %rand(1)*ones(nFeature,1);



%% run AsynElasticNet -- Asyn-ElasticNet
current = pwd;
cd('./matlab/AsynElasticNet')

prob_ElasticNet = problem_ElasticNet(X, y, l2, l1);
tic
[w_ElasticNet, obj_ElasticNet] = AsynElasticNet(prob_ElasticNet, nThread, w0, lbound, ubound, maxEpoch, minObj);
toc
cd(current)

figure
semilogy(obj_ElasticNet)
title('Asyn-ElasitcNet')
ylabel('log\_Obj')
xlabel('#Epoch')

