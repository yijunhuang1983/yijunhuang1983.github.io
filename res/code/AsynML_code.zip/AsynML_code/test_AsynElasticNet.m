function test_AsynElasticNet

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear;clc; close all

randn('state',1)
rand('state',1)

%% generate data-set

% the number of samples
nSample = 100;
% the number of features
nFeature = 400;

% noise level used in generateData()
noise_level = 0.1;

% generate data-set: 
% X -- data matrix [nSample,nFeature]
% y -- target values of data X [nSample,1]

[X, y] = generateData(nSample, nFeature, noise_level);

%% settings

% the number of threads
nThread = 4;

% l1 -- The prior parameter of l2-norm regularization (non-negative double).
l1 = 0.2;

% l2 -- The prior parameter of l2-norm regularization (non-negative double).
l2 = 0.5; 

% w0 -- the initial value of varialbes (empty [] or double or vector [nFeature,1].
w0 = []; % 1; %randn(nFeature,1);

% Stopping criteria: the limit the of epochs (positive integer).
maxEpoch = 60;
% minObj -- Stopping criteria: the limit of objective function value (double).
minObj = 0;

% lower and upper bound of variable vector (empty [] or double or vector [nFeature,1]).
% constraint: lbound <= ubound
lbound = [];  %-1; %-rand(1)*ones(nFeature,1);
ubound = []; % 1;  %rand(1)*ones(nFeature,1);



%% run AsynElasticNet -- Asyn-ElasticNet
current = pwd;
cd('./matlab/AsynElasticNet')

prob_ElasticNet = problem_ElasticNet(X, y, l2, l1);
tic
[w_ElasticNet, obj_ElasticNet] = AsynElasticNet(prob_ElasticNet, nThread, w0, lbound, ubound, maxEpoch, minObj);
toc
cd(current)

figure
semilogy(obj_ElasticNet)
title('Asyn-ElasitcNet')
ylabel('log\_Obj')
xlabel('#Epoch')


return

function [X, y] = generateData(nSample, nFeature, noise_level)

% construct data set -- X(nSample x nFeature)
X = randn(nSample,nFeature); 

% variable vector -- w(nFeature x 1)
w = randn(nFeature,1);

% target value of data X -- y(nSample x 1)
y = X*w + randn(nSample,1)*noise_level;

return