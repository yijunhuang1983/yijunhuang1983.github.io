function prob = problem_Lasso(X, y, l1)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- Sample-set (matrix [nSample,#Feature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  l1 -- The prior parameter of l1-norm regularization (non-negative double).
%% output:
%  prob -- the input data for AsynLasso()


inputErr = false;

nSample = size(X,1);

if ~(isvector(y) && (length(y)==nSample))
	inputErr = true;
end

if l1<0
    inputErr = true;
else
    l1 = double(l1);
end

if inputErr
    fprintf('\nproblem_Lasso: error in inputs\n');
    return;
end

prob.Q = X'*X/nSample;
prob.B = y'*X/nSample;
prob.C = y'*y/(2*nSample);
prob.l1 = l1;

end