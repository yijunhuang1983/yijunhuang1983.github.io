function prob = problem_RidgeRegression(X, y, l2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% inputs:
%  X -- Sample-set (matrix [nSample,#Feature]).
%  y -- Target values of samples X (vector [nSample,1]).
%  l2 -- The prior parameter of l2-norm regularization (non-negative double).
%% output:
%  prob -- the input data for AsynRidgeRegression()


inputErr = false;

[nSample, nFeature] = size(X);

if ~(isvector(y) && (length(y)==nSample))
	inputErr = true;
end

if l2<0
    inputErr = true;
else
    l2 = double(l2);
end

if inputErr
    fprintf('\nproblem_RidgeRegression: error in inputs\n');
    return;
end

prob.Q = X'*X/nSample + l2*eye(nFeature);
prob.B = y'*X/nSample;
prob.C = y'*y/(2*nSample);

end