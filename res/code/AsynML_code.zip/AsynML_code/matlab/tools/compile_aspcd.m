
function compile_aspcd(L1, outpath)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% @author:  Yijun Huang                 %
% @email:   yijun.huang.1983@gmail.com  %
% @version: 1.1 (Nov. 2016)             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% aspcd is implemented to solve:
% min w'*Q*w/2 - B'*w + C + l1*norm(w,1)
% s.t. lbound<= w <= ubount

%%
% L1: true -- with l1-norm
%     false -- without l1-norm
%%
if ismac
    % Code to run on Mac plaform
    if (L1)
        eval(['mex ./../../src/m_aspcd.c ./../../src/aspcd.c ./../../src/utl.c -lpthread -D_MATLAB_ -D_APPLE_ -D_L1_ -outdir ', outpath])
    else     
        eval(['mex ./../../src/m_aspcd.c ./../../src/aspcd.c ./../../src/utl.c -lpthread -D_MATLAB_ -D_APPLE_ -outdir ', outpath])
    end
    
elseif isunix
    % Code to run on Linux plaform
    if (L1)
        eval(['mex ./../../src/m_aspcd.c ./../../src/aspcd.c ./../../src/utl.c -lpthread -D_MATLAB_ -D_L1_ -outdir ', outpath])
    else
        eval(['mex ./../../src/m_aspcd.c ./../../src/aspcd.c ./../../src/utl.c -lpthread -D_MATLAB_ -outdir ', outpath])
    end

    
elseif ispc
    % Code to run on Windows platform
	disp('Windows Platform not supported')
    
else
    disp('Platform not supported')
    
end






