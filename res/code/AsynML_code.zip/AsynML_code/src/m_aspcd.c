/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "./../src/header.h"
#include "./../src/utl.h"
#include "mex.h"


void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	mxArray *pm;
	double *ptr, *Q, *B, C, l1, minObj, *w0, *w, *objList, *lbound, *ubound;
	unsigned long nThread, maxEpoch, p, nEpoch, i;

    
    if(nrhs != 10)
		mexErrMsgTxt( "MATLAB:aspcd: Nine inputs required.");
    
	ptr = mxGetPr(prhs[0]);
	nThread = (unsigned long)(*ptr);
    
    
    Q = mxGetPr(prhs[1]);
    B = mxGetPr(prhs[2]);
    ptr = mxGetPr(prhs[3]);
    C = *ptr;
    p = mxGetN(prhs[1]);
    
    plhs[0] = mxCreateDoubleMatrix(p, 1, mxREAL);
    w = mxGetPr(plhs[0]);
    if ((mxGetM(prhs[4])==0) && (mxGetN(prhs[4])==0))
    {
        for (i=0; i<p; i++)
            w[i] = 0;
    }
    else
    {
        w0 = mxGetPr(prhs[4]);
        if ((mxGetM(prhs[4])==1) && (mxGetN(prhs[4])==1))
        {
            for (i=0; i<p; i++)
                w[i] = *w0;
        }
        else if (((mxGetM(prhs[4])==1) && (mxGetN(prhs[4])==p)) || ((mxGetM(prhs[4])==p) && (mxGetN(prhs[4])==1)))
            memcpy(w, w0, p*sizeof(double));
        else
            mexErrMsgTxt( "MATLAB:error in the initial value.");
    }
    
    
    ptr = mxGetPr(prhs[5]);
    l1 = *ptr;
    
    if ((mxGetN(prhs[6])==0) || (mxGetM(prhs[6])==0))
    {
        lbound = 0;
    }
    else
    {
        lbound = mxGetPr(prhs[6]);
    }
    
    if ((mxGetN(prhs[7])==0) || (mxGetM(prhs[7])==0))
    {
        ubound = 0;
    }
    else
    {
        ubound = mxGetPr(prhs[7]);
    }
    
    
    
    ptr = mxGetPr(prhs[8]);
    maxEpoch = (unsigned long)(*ptr);
    ptr = mxGetPr(prhs[9]);
    minObj = *ptr;

	pm = mxCreateDoubleMatrix(maxEpoch, 1, mxREAL);
	objList = mxGetPr(pm);


    nEpoch = aspcd(nThread, p, Q, B, C, l1, lbound, ubound, maxEpoch, minObj, w, objList);
    
    PRINTF("\nnEpoch=%i\n", nEpoch);
    
    if (nEpoch==FALSE) {
        mexErrMsgTxt( "MATLAB:error in computing.");
    }
 
	plhs[1] = mxCreateDoubleMatrix(nEpoch, 1, mxREAL);
	ptr = mxGetPr(plhs[1]);
	memcpy(ptr, objList, nEpoch*sizeof(double));
	mxDestroyArray(pm);
    


	return;
}

