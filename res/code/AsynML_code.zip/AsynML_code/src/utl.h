/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#ifndef _UTL_H_
#define _UTL_H_

#include "header.h"



#ifdef _APPLE_

typedef struct {
  pthread_mutex_t mux;
  pthread_cond_t cond;
  int total;
  int current;
} barrier_t;

#else

typedef pthread_barrier_t barrier_t;

#endif



extern int barrier_init(barrier_t *b, void* attr, int count); 
extern int barrier_wait(barrier_t *b); 
extern int barrier_destroy(barrier_t *b); 

extern UINT RandUnsignedInt(UINT range);
extern void Shuffle (UINT * p, UINT low, UINT len);
extern void split (UINT index, UINT Len, UINT nPortion, UINT *pStart, UINT *pEnd);


extern UINT g_seed;
extern BOOL g_finish;
extern barrier_t b_wait;


#endif
