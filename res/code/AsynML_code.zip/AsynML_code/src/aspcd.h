/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#ifndef _ASPCD_H_
#define _ASPCD_H_

#include "header.h"

typedef struct
{
	UINT id;
	UINT nThread;

	FLOAT* Q;
	FLOAT* w;
	FLOAT* B;
    FLOAT C;
    
	FLOAT l1;

	FLOAT *lbound;
	FLOAT *ubound;

	FLOAT *stepsize;

	UINT p;

	FLOAT obj;

	UINT *iBuffer;

} THRARGU_TRAIN;


extern UINT aspcd (UINT nThread, UINT p, FLOAT* Q, FLOAT* B, FLOAT C, FLOAT l1, FLOAT *lbound, FLOAT *ubound, UINT maxEpoch, FLOAT minObj, FLOAT* w, FLOAT *objList);


/* object function: (1/2) * ||w'*Q*w - B||^2 + l1*||w||_1  */

#endif
