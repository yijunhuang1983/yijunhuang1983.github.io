/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/


#ifndef _HEADER_H_
#define _HEADER_H_

#include <stdio.h>      /* printf, scanf, puts, NULL */
#include <stdlib.h>     /* srand, rand */
#include <time.h>       /* time */
#include <sys/time.h> 
#include <float.h>
#include <pthread.h>

#include <limits.h>
#include <math.h>
#include <errno.h>



/*=======================================================================================================================*/

#define		UINT         unsigned long 
#define 	INT          long 

#define 	FLOAT        double

#ifdef _MATLAB_
#define 	PRINTF       mexPrintf
#else
#define 	PRINTF       printf
#endif



#define 	FREE         free
#define 	MALLOC       malloc

#define 	PRT_FLT      0.10lf



#ifndef BOOL
#define BOOL unsigned long
#endif


#ifndef TRUE
#define TRUE 1
#endif


#ifndef FALSE
#define FALSE 0
#endif


#ifndef _EPS_
#define _EPS_  2.2204e-16
#endif

#ifndef _FLT_MIN_
#define _FLT_MIN_  -3.40282e+38
#endif

#ifndef _FLT_MAX_
#define _FLT_MAX_  3.40282e+38
#endif
	

#ifndef _INF_
#define _INF_    _FLT_MAX_  
#endif
/*=======================================================================================================================*/




#endif
