/*
@author:  Yijun Huang
@email:   yijun.huang.1983@gmail.com
@version: 1.1 (Nov. 2016)
*/

#include "ark.h"
#include "utl.h"
#include "mex.h"



void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    mxArray *pm;
    
    unsigned long nThread, maxEpoch, nEpoch, i;

    double *ptr;
    
    size_t *irAt, *jcAt;
    double *srAt;
    
    double *b, *x, *x0, stepsize, minResidual, *residual_list;
   	mwSignedIndex m,n, M, N;
    
    if(nrhs != 7)
        mexErrMsgTxt( "MATLAB:ark: 7 inputs required.");
    
    if(nlhs != 2)
        mexErrMsgTxt( "MATLAB:ark: 2 outputs required.");
    
    ptr = mxGetPr(prhs[0]);
    nThread = (unsigned long)(*ptr);
    
    srAt  = mxGetPr(prhs[1]);
    irAt = mxGetIr(prhs[1]);
    jcAt = mxGetJc(prhs[1]);
    
    b = mxGetPr(prhs[2]);
    
    N = (mwSignedIndex)mxGetM(prhs[1]);
    M = (mwSignedIndex)mxGetN(prhs[1]);
    
    plhs[0] = mxCreateDoubleMatrix(N, 1, mxREAL);
    x = mxGetPr(plhs[0]);
    if ((mxGetM(prhs[3])==0) && (mxGetN(prhs[3])==0))
    {
        for (i=0; i<N; i++)
            x[i] = 0;
    }
    else
    {
        x0 = mxGetPr(prhs[3]);
        if ((mxGetM(prhs[3])==1) && (mxGetN(prhs[3])==1))
        {
            for (i=0; i<N; i++)
                x[i] = *x0;
        }
        else if (((mxGetM(prhs[3])==1) && (mxGetN(prhs[3])==N)) || ((mxGetM(prhs[3])==N) && (mxGetN(prhs[3])==1)))
            memcpy(x, x0, N*sizeof(double));
        else
        {
            for (i=0; i<N; i++)
                x[i] = 0;
        }
    }
    
    
    ptr = mxGetPr(prhs[4]);
    stepsize = *ptr;
    
    ptr = mxGetPr(prhs[5]);
    maxEpoch = (unsigned long)(*ptr);
    
    ptr = mxGetPr(prhs[6]);
    minResidual = *ptr;
    
    pm = mxCreateDoubleMatrix(maxEpoch, 1, mxREAL);
    residual_list = mxGetPr(pm);
    

    /* call */

	PRINTF("\nnThread=%i, M=%i, N=%i, stepsize=%f, maxEpoch=%i, minResidual=%f\n", nThread,M, N, stepsize, maxEpoch, minResidual);

    nEpoch = ark(nThread, M, N, srAt, irAt, jcAt, b, x, stepsize, maxEpoch, minResidual, residual_list);
    
    if (nEpoch==FALSE) {
        mexErrMsgTxt( "MATLAB:error in computing.");
    }
    
    plhs[1] = mxCreateDoubleMatrix(nEpoch, 1, mxREAL);
    ptr = mxGetPr(plhs[1]);
    memcpy(ptr, residual_list, nEpoch*sizeof(double));
    mxDestroyArray(pm);
    
}

